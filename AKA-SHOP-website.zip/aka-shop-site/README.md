# AKA SHOP — Store & Gaming Arena

Responsive single-page frontend prototype for AKA SHOP.

## Included
- Premium dark-and-gold homepage
- Storefront placeholder cards
- Playable top-down Cyber Rush browser demo
- Local-only demo leaderboard
- Admin settings preview for manual ON/OFF, schedule, session duration, cooldown and attempts
- Reward approval preview

## Important limitations
This is a **frontend prototype only**, not ready for a live competition or real purchases.
- Admin controls are not authenticated and only affect the demo page.
- Scores are stored in the browser and can be manipulated; they are not trusted.
- No signup/login, database, payment checkout, server-enforced schedule/cooldown or real reward approval is connected.
- Do not issue real rewards based on demo scores.

## Publish using GitHub Pages
1. Open your repository on GitHub.
2. Select **Add file → Upload files**.
3. Upload `index.html` and `README.md` from this folder and commit the changes to `main`.
4. Go to **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
6. Wait for the Pages URL to appear in Settings → Pages.

## Production next steps
1. Configure Supabase Auth and PostgreSQL.
2. Add database migrations and Row Level Security policies.
3. Implement authenticated Edge Functions for admin settings, session creation, server-validated score events, weekly leaderboard finalization and reward approval.
4. Connect real player profiles and store catalogue/checkout.
5. Test schedule boundaries, cooldown, duplicate requests, permissions, tie-breaks and weekly rollover.
